from django.shortcuts import render,redirect, render_to_response,HttpResponseRedirect
from django.db import connection 
#from bus.models import busr,booking 
from django.http import HttpResponse 
from django.template import Context 
from django.template.loader import get_template 
from django.template import Template, Context
from django.db import models
from django.contrib import messages
from django.contrib import messages
#from bus.forms import LoginForm
from django.core.mail import send_mail
from django.core.mail import EmailMessage
import datetime
# Create your views here.

def searchlogin(request):
	cursor=connection.cursor()
	p=request.GET['username']
	q=request.GET['password']
	sql2="select * from tbl_login where username='%s' and password='%s' and status='true'" %(p,q)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		sql3 = "select * from tbl_login  where username='%s' and password='%s'" % (p, q)
		cursor.execute(sql3)
		result1 = cursor.fetchall()
		for row1 in result1:
			d = row1[3]
			x=row1[2]
		request.session['username'] = p
		request.session['u_id'] = d
		request.session['user_type'] =x
		if(x=='admin'):
			return render(request ,'reg_admin.html') 
		elif(x=='employer'):
			return render(request,'reg_emp.html')
		elif(x=='police'):
			return render(request,'reg_policestation.html')
	else:
		html="<script>alert('invalid password and username ');window.location='/login/';</script>"
		return HttpResponse(html)
def logout(request):
	try:
		del request.session['u_id']
		del request.session['user_type']
	except:
		pass
	return HttpResponse("<script>alert('you are loged out');window.location='/login/';</script>")

def reginsert(request):
	id=0
	Name=request.GET['admin_name'] 
	Country=request.GET['country']
	State=request.GET['state']
	Phone=int(request.GET['Phone'])
	Mobile=int(request.GET['Mobile'])
	Email_id=request.GET['Email_id']
	Password=request.GET['Password']
	
	cursor=connection.cursor()
	sql4="insert into tbl_admin(name,country,state,phone,mobile,email,pasw) values('%s','%s','%s',%d,%d,'%s','%s')"%(Name,Country,State,Phone,Mobile,Email_id,Password)  
	cursor.execute(sql4)
	sqlad="select max(admin_id) from tbl_admin"
	result=cursor.fetchall()
	for row in result: 
		id=int(row[0])
	sql="insert into tbl_login(username,password,user_type,u_id,status)values('%s','%s','%s','%d','%s')"%(Email_id,Password,'admin','false')
	cursor.execute(sql)
	html="<script>alert('successfully registered! ');window.location='/l/';</script>"
	return HttpResponse(html)
	
def regempinsert(request):
		Name=request.GET['Emp_name'] 
		Gender=request.GET['Gender']
		Office_name=request.GET['Firm_name']
		Aadhar_number=int(request.GET['Aadhar_number'])
		DOB=request.GET['DOB']
		Address=request.GET['Emp_address']
		Place=request.GET['Place']
		Phone=int(request.GET['Phone'])
		Mobile=int(request.GET['Mobile'])
		Email_id=request.GET['Email_id']
		Passwd=request.GET['Password']

		cursor=connection.cursor()
		sql4="insert into tbl_emp(name,gender,firm_name,aadhar_no,dob,emp_address,place,phone,mobile,email,pswd,status) values('%s','%s','%s','%d','%s','%s','%s','%d','%d','%s','%s','%s')"%(Name,Gender,Office_name,Aadhar_number,DOB,Address,Place,Phone,Mobile,Email_id,Passwd,'pending')  
		cursor.execute(sql4)
		sqlemp="select max(emp_id) from tbl_emp"
		cursor.execute(sqlemp)
		result=cursor.fetchall()
		for row in result: 
			id=int(row[0])
		sql="insert into tbl_login(username,password,user_type,u_id,status)values('%s','%s','%s','%d','%s')"%(Email_id,Passwd,'employer',id,'false')
		cursor.execute(sql)
		html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		return HttpResponse(html)
def regpoliceinsert(request):
		Branch=request.GET['branch'] 
		Address=request.GET['address']
		
		
		Phone=int(request.GET['Phone'])
		Mobile=int(request.GET['Mobile'])
		Email_id=request.GET['Email_id']
		District=request.GET['district']
		City=request.GET['city']
		State=request.GET['state']
		
		Password=request.GET['Password']

		cursor=connection.cursor()
		sql4="insert into tbl_policestation(branch,address,phone,mobile,email,district,city,state,password) values('%s','%s','%d','%d','%s','%s','%s','%s','%s')"%(Branch,Address,Phone,Mobile,Email_id,District,City,State,Password)  
		cursor.execute(sql4)
		html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		return HttpResponse(html)
def regworkerinsert(request):
		Name=request.GET['name'] 
		Gender=request.GET['Gender']
		DOB=request.GET['DOB']
		Aadhar_number=request.GET['Aadhar_number']
		now=datetime.datetime.today()
		Place=request.GET['Place']
		Address=request.GET['address']
		Languages_known=request.GET['Languages_known']
		Phone=request.GET['Phone']
		Mobile=request.GET['Mobile']
		Email_id=request.GET['Email_id']
		

		cursor=connection.cursor()
		sql4="insert into tbl_worker(worker_name,gender,dob,aadhar_number,regis_date,place,address,languages_known,phone,mobile,email,status) values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(Name,Gender,DOB,Aadhar_number,now,Place,Address,Languages_known,Phone,Mobile,Email_id,'PENDING')  
		cursor.execute(sql4)
		html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		return HttpResponse(html)
def vacancyinsert(request):
		now=datetime.datetime.today()
		Vacancy=request.GET['vacancy'] 
		Vacancy_num=request.GET['num']
		Description=request.GET['description']

		cursor=connection.cursor()
		sql4="insert into tbl_vacancy(worker_name,gender,dob,aadhar_number,regis_date,place,address,languages_known,phone,mobile,email,status) values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(Name,Gender,DOB,Aadhar_number,now,Place,Address,Languages_known,Phone,Mobile,Email_id,'PENDING')  
		cursor.execute(sql4)
		html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		return HttpResponse(html)
def viewempaccept(request):
		cursor=connection.cursor()
		list=[]
		sql="select * from tbl_login where user_type='employer' and status='false'"
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_emp where emp_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
					list.append(dict)
		return render(request,'view_emp.html',{'list':list})
					
		
		


