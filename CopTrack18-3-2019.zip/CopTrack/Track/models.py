from django.db import models
#from __future__ import unicode_literals

# Create your models here.
class worker(models.Model):
	image = models.FileField(upload_to='pictures')
	worker_name = models.CharField(max_length=50)
	gender = models.CharField(max_length=50)
	dob= models.CharField(max_length=50)
	aadhar_number = models.CharField(max_length=50)
	regis_date = models.CharField(max_length=50)
	place = models.CharField(max_length=50)
	address = models.CharField(max_length=100)
	languages_known = models.CharField(max_length=100)
	phone=models.CharField(max_length=10)
	mobile=models.CharField(max_length=10)
	email=models.CharField(max_length=50)
	paswd=models.CharField(max_length=50)
	status=models.CharField(max_length=50)
	class Meta:
		db_table = "tbl_worker"
		
		