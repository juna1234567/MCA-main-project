from django import forms
from django.forms import CharField
from Track.models import worker
class workerform(forms.Form):
	worker_name = forms.CharField(max_length=50)
	gender = forms.CharField(max_length=50)
	dob = forms.CharField(max_length=50)
	aadhar_number = forms.CharField(max_length=50)
	'''regis_date = forms.CharField(max_length=50)
	place = forms.CharField(max_length=50)
	address = forms.CharField(max_length=100)
	languages_known = forms.CharField(max_length=100)
	phone = forms.CharField(max_length=10)
	
	mobile = forms.CharField(max_length=10)
	email = forms.CharField(max_length=50)
	paswd = forms.CharField(max_length=50)'''
	image = forms.FileField()
	class Meta:
		model = worker
		fields = ['image','worker_name','gender','dob','aadhar_number', 'regis_date', 'place','address','languages_known','phone', 'mobile','email','paswd','status']
