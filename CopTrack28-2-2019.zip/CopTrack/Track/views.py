from django.shortcuts import render,redirect, render_to_response,HttpResponseRedirect
from django.db import connection 
#from bus.models import busr,booking 
from django.http import HttpResponse 
from django.template import Context 
from django.template.loader import get_template 
from django.template import Template, Context
from django.db import models
from django.contrib import messages
from django.contrib import messages
#from bus.forms import LoginForm
from django.core.mail import send_mail
from django.core.mail import EmailMessage
# Create your views here.
def reginsert(request):
	Name=request.GET['admin_name'] 
	Country=request.GET['country']
	State=request.GET['state']
	Phone=int(request.GET['Phone'])
	Mobile=int(request.GET['Mobile'])
	Email_id=request.GET['Email_id']
	Password=request.GET['Password']
	
	cursor=connection.cursor()
	sql4="insert into tbl_admin(name,country,state,phone,mobile,email,pasw) values('%s','%s','%s',%d,%d,'%s','%s')"%(Name,Country,State,Phone,Mobile,Email_id,Password)  
	cursor.execute(sql4)
	html="<script>alert('successfully registered! ');window.location='/l/';</script>"
	return HttpResponse(html)
	
def regempinsert(request):
		Name=request.GET['Emp_name'] 
		Gender=request.GET['Gender']
		Office_name=request.GET['Firm_name']
		Aadhar_number=int(request.GET['Aadhar_number'])
		DOB=request.GET['DOB']
		Address=request.GET['Emp_address']
		Place=request.GET['Place']
		Phone=int(request.GET['Phone'])
		Mobile=int(request.GET['Mobile'])
		Email_id=request.GET['Email_id']
		Passwd=request.GET['Password']

		cursor=connection.cursor()
		sql4="insert into tbl_emp(name,gender,firm_name,aadhar_no,dob,emp_address,place,phone,mobile,email,pswd,status) values('%s','%s','%s','%d','%s','%s','%s','%d','%d','%s','%s','%s')"%(Name,Gender,Office_name,Aadhar_number,DOB,Address,Place,Phone,Mobile,Email_id,Passwd,'pending')  
		cursor.execute(sql4)
		html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		return HttpResponse(html)
def regpoliceinsert(request):
		Branch=request.GET['branch'] 
		Address=request.GET['address']
		
		
		Phone=int(request.GET['Phone'])
		Mobile=int(request.GET['Mobile'])
		Email_id=request.GET['Email_id']
		District=request.GET['district']
		City=request.GET['city']
		State=request.GET['state']
		
		Password=request.GET['Password']

		cursor=connection.cursor()
		sql4="insert into tbl_policestation(branch,address,phone,mobile,email,district,city,state,password) values('%s','%s','%d','%d','%s','%s','%s','%s','%s')"%(Branch,Address,Phone,Mobile,Email_id,District,City,State,Password)  
		cursor.execute(sql4)
		html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		return HttpResponse(html)

