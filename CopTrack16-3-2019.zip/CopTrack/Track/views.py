from django.shortcuts import render,redirect, render_to_response,HttpResponseRedirect
from django.db import connection 
#from bus.models import busr,booking 
from django.http import HttpResponse 
from django.template import Context 
from django.template.loader import get_template 
from django.template import Template, Context
from django.db import models
from django.contrib import messages
from django.contrib import messages
from Track.forms import workerform
from Track.models import worker
from django.core.mail import send_mail
from django.core.mail import EmailMessage
import datetime 
now=datetime.datetime.today()
# Create your views he

def searchlogin(request):
	cursor=connection.cursor()
	p=request.GET['username']
	q=request.GET['password']
	sql2="select * from tbl_login where username='%s' and password='%s' and status='true'" %(p,q)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		sql3 = "select * from tbl_login  where username='%s' and password='%s'" % (p, q)
		cursor.execute(sql3)
		result1 = cursor.fetchall()
		for row1 in result1:
			d = row1[3]
			x=row1[2]
		request.session['username'] = p
		request.session['u_id'] = d
		request.session['user_type'] =x
		if(x=='admin'):
			return render(request ,'home_admin.html') 
		elif(x=='employer'):
			#return HttpResponse(request.session['u_id'])
			return render(request,'home_emp.html')
		elif(x=='police'):
			return render(request,'home_police.html')
		elif(x=='worker'):
			return render(request,'home_worker.html')
	else:
		html="<script>alert('invalid password and username ');window.location='/l/';</script>"
		return HttpResponse(html)
def logout(request):
	try:
		del request.session['u_id']
		del request.session['user_type']
	except:
		pass
	return HttpResponse("<script>alert('you are loged out');window.location='/l/';</script>")

def reginsert(request):
	id=0
	Name=request.GET['admin_name'] 
	Country=request.GET['country']
	State=request.GET['state']
	Phone=request.GET['Phone']
	Mobile=request.GET['Mobile']
	Email_id=request.GET['Email_id']
	Password=request.GET['Password']
	
	cursor=connection.cursor()
	sql4="insert into tbl_admin(name,country,state,phone,mobile,email,pasw) values('%s','%s','%s','%s','%s','%s','%s')"%(Name,Country,State,Phone,Mobile,Email_id,Password)  
	cursor.execute(sql4)
	sqlad="select max(admin_id) from tbl_admin"
	result=cursor.fetchall()
	for row in result: 
		id=int(row[0])
	sql="insert into tbl_login(username,password,user_type,u_id,status)values('%s','%s','%s','%d','%s')"%(Email_id,Password,'admin',id,'true')
	cursor.execute(sql)
	html="<script>alert('successfully registered! ');window.location='/l/';</script>"
	return HttpResponse(html)
	
def regempinsert(request):
		Name=request.GET['Emp_name'] 
		Gender=request.GET['Gender']
		Office_name=request.GET['Firm_name']
		Aadhar_number=request.GET['Aadhar_number']
		DOB=request.GET['DOB']
		Address=request.GET['Emp_address']
		Place=request.GET['Place']
		Phone=int(request.GET['Phone'])
		Mobile=int(request.GET['Mobile'])
		Email_id=request.GET['Email_id']
		Passwd=request.GET['Password']
		Re_passwd=request.GET['re_Password']
		if(Passwd==Re_passwd):
			cursor=connection.cursor()
			sql2="select * from tbl_login where username='%s'" %(Email_id)
			cursor.execute(sql2)
			result=cursor.fetchall()
			if 	(cursor.rowcount) > 0:
				html="<script>alert('Already Registerd');window.location='/home/';</script>"
			else:
				sql4="insert into tbl_emp(name,gender,firm_name,aadhar_no,dob,emp_address,place,phone,mobile,email,pswd,status) values('%s','%s','%s','%s','%s','%s','%s','%d','%d','%s','%s','%s')"%(Name,Gender,Office_name,Aadhar_number,DOB,Address,Place,Phone,Mobile,Email_id,Passwd,'pending')  
				cursor.execute(sql4)
				sqlemp="select max(emp_id) from tbl_emp"
				cursor.execute(sqlemp)
				result=cursor.fetchall()
				for row in result: 
					id=int(row[0])
				sql="insert into tbl_login(username,password,user_type,u_id,status)values('%s','%s','%s','%d','%s')"%(Email_id,Passwd,'employer',id,'false')
				cursor.execute(sql)
				html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		else:
			html="<script>alert('Password and Re_passsword are not matched! ');window.location='/home/';</script>"
		return HttpResponse(html)
def regpoliceinsert(request):
		Branch=request.GET['branch'] 
		Address=request.GET['address']
		
		
		Phone=int(request.GET['Phone'])
		Mobile=int(request.GET['Mobile'])
		Email_id=request.GET['Email_id']
		District=request.GET['district']
		City=request.GET['city']
		State=request.GET['state']
		
		Password=request.GET['Password']

		cursor=connection.cursor()
		sql4="insert into tbl_policestation(branch,address,phone,mobile,email,district,city,state,password) values('%s','%s','%d','%d','%s','%s','%s','%s','%s')"%(Branch,Address,Phone,Mobile,Email_id,District,City,State,Password)  
		cursor.execute(sql4)
		sqlpolice="select max(station_id) from tbl_policestation"
		cursor.execute(sqlpolice)
		result=cursor.fetchall()
		for row in result: 
			id=int(row[0])
		sql="insert into tbl_login(username,password,user_type,u_id,status)values('%s','%s','%s','%d','%s')"%(Email_id,Password,'police',id,'true')
		cursor.execute(sql)
		html="<script>alert('successfully registered! ');window.location='/l/';</script>"
		return HttpResponse(html)
def regworkerinsert(request):
	cursor=connection.cursor()
	Email=request.POST['email1']
	Passwd=request.POST['paswd1']
	saved = False
	if request.method == "POST":
		MyProfileForm = workerform(request.POST, request.FILES)
		if MyProfileForm.is_valid():
				profile = worker()
				profile.image = MyProfileForm.cleaned_data["image"]
				profile.worker_name = MyProfileForm.cleaned_data["worker_name"]
				profile.gender = MyProfileForm.cleaned_data["gender"]
				profile.dob = MyProfileForm.cleaned_data["dob"]
				profile.aadhar_number=MyProfileForm.cleaned_data["aadhar_number"]
				profile.regis_date=now
				profile.place=request.POST["place1"]
				profile.address=request.POST["address1"]
				profile.languages_known=request.POST["languages_known1"]
				profile.phone=request.POST["phone1"]
				profile.mobile=request.POST["mobile1"]
				profile.email=request.POST["email1"]
				profile.paswd=request.POST["paswd1"]
				profile.status='Pending'
				profile.save()
				html = "<script>alert('successfully Registerd! ');window.location='/homeadmin/';</script>"
				saved = True
	else:
				MyProfileForm =workerform()
	#return HttpResponse(html)
	
	sqlworker="select max(worker_id) from tbl_worker"
	cursor.execute(sqlworker)
	result=cursor.fetchall()
	for row in result: 
		id=int(row[0])
		sql="insert into tbl_login(username,password,user_type,u_id,status)values('%s','%s','%s','%d','%s')"%(Email,Passwd,'worker',id,'false')
		cursor.execute(sql)
	html="<script>alert('successfully registered! ');window.location='/homeadmin/';</script>"
	return HttpResponse(html)
		
def vacancyinsert(request):
		now=datetime.datetime.today()
		emp_id=request.session['u_id']
		Vacancy=request.GET['vacancy'] 
		Vacancy_num=request.GET['num']
		Description=request.GET['description']
		cursor=connection.cursor()
		
		sql4="insert into tbl_vacancy(date,emp_id,vacancy,vacancy_no,description)values('%s','%s','%s','%s','%s')"%(now,emp_id,Vacancy,Vacancy_num,Description) 
		cursor.execute(sql4)
		html="<script>alert('successfully inserted! ');window.location='/homeemp/';</script>"
		return HttpResponse(html)
def noc_insert1(request):
	cursor=connection.cursor()
	list=[]
	sql="select * from tbl_login where user_type='worker'"
	cursor.execute(sql)
	result1=cursor.fetchall()
	for row1 in result1:
		sql6="select * from tbl_worker where worker_id='%s'"%(row1[3])
		cursor.execute(sql6)
		result=cursor.fetchall()
		for row in result:
			dict1={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'regis_date':row[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
			list.append(dict1)
	return render(request,'noc_insert1.html',{'list':list})
def addnoc(request):
	worker_id=request.GET['worker_id']
	return render(request,'noc.html',{'worker_id':worker_id})
def noc_insert(request):
		worker_id=request.GET['worker_id']
		station_id=request.session['u_id']
		now=datetime.datetime.today()
		Crime=request.GET['crime'] 
		Description=request.GET['description']
		cursor=connection.cursor()
		sql4="insert into tbl_noc(worker_id,station_id,date,crime,crime_details)values('%s','%s','%s','%s','%s')"%(worker_id,station_id,now,Crime,Description) 
		cursor.execute(sql4)
		html="<script>alert('successfully inserted! ');window.location='/homepolice/';</script>"
		return HttpResponse(html)
def viewvacancydetails(request):
		cursor=connection.cursor()
		list=[]
		sql="select * from tbl_emp "
		
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row in result1:
			sql1="select * from tbl_vacancy where emp_id='%s'"%(row[0])
			cursor.execute(sql1)
			result=cursor.fetchall()
			for row1 in result:
				dict={'vacancy_id':row1[0],'date':row1[1],'emp_id':row1[2],'vacancy':row1[3],'vacancy_no':row1[4],'description':row1[5],'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
				list.append(dict)
		return render(request,'view_vacancy.html',{'list':list})

def insertworkerdetails(request):
		worker_id=request.session['u_id']
		vacancy_id=request.session['u_id']
		
		
		Experience=request.GET['experience'] 
		
		Qualification=request.GET['qualification']
		cursor=connection.cursor()
		
		sql4="insert into tbl_workerdetails(worker_id,vacancy_id,experience,qualification)values('%s','%s','%s','%s')"%(worker_id,vacancy_id,Experience,Qualification) 
		cursor.execute(sql4)
		html="<script>alert('successfully inserted! ');window.location='/viewvacancydetails/';</script>"
		return HttpResponse(html)
def viewemprequest(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='employer' and status='false'"
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_emp where emp_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
					list.append(dict)
		return render(request,'view_emp.html',{'list':list})
def viewacceptemprequest(request):
		cursor=connection.cursor()
		emp_id=request.GET['emp_id']
		sql1="select * from tbl_emp where emp_id='%s'" %(emp_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row in result:
			dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
			list.append(dict)
		return render(request,'view_idividual_emp.html',{'list':list})
def acceptemprequest(request):
		emp_id=request.GET['empid']
		cursor=connection.cursor()
		sql5="update tbl_login set status='true' where u_id='%s' and user_type='employer'" %(emp_id)
		
		cursor.execute(sql5)
		sql7="update tbl_emp set status='Active' where emp_id='%s'" %(emp_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Accepted! ');window.location='/viewemprequest/';</script>"
		return HttpResponse(html)
def rejectemprequest(request):
		emp_id=request.GET['empid']
		cursor=connection.cursor()
		sql5="update tbl_login set status='true' where u_id='%s' and user_type='employer'" %(emp_id)
		
		cursor.execute(sql5)
		sql7="update tbl_emp set status='Rejected' where emp_id='%s'" %(emp_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Rejected! ');window.location='/viewemprequest/';</script>"
		return HttpResponse(html)
		
def viewworkeraccept(request):
	cursor=connection.cursor()
	list=[]
	sql="select * from tbl_login where user_type='worker' and status='false'"
	cursor.execute(sql)
	result1=cursor.fetchall()
	for row1 in result1:
		sql6="select * from tbl_worker where worker_id='%s'"%(row1[3])
		cursor.execute(sql6)
		result=cursor.fetchall()
		for row in result:
			dict={'worker_id':row[0],'image':row[1],'worker_name':row[2],'gender':row[3],'dob':row[4],'aadhar_number':row[5],'regis_date':row[6],'place':row[7],'address':row[8],'languages_known':row[9],'phone':row[10],'mobile':row[11],'email':row[12],'status':row[14]}
			list.append(dict)
	return render(request,'view_worker.html',{'list':list})
def viewnocaccept(request):
		cursor=connection.cursor()
		list=[]
		worker_id=request.GET['worker_id']
		sql1="select * from tbl_noc where worker_id='%s'"%(worker_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		if 	(cursor.rowcount) > 0:
			for row in result:
				dict={'noc_id':row[0],'worker_id':row[1],'station_id':row[2],'date':row[3],'crime':row[4],'crime_details':row[5]}
				list.append(dict)
			return render(request,'viewnocaccept2.html',{'list':list})
		else:
			html="<script>alert('No NOC added please find details of worker! ');window.location='/homepolice/';</script>"
			return HttpResponse(html)
def viewacceptworkerrequest(request):
		cursor=connection.cursor()
		worker_id=request.GET['worker_id']
		sql1="select * from tbl_worker where worker_id='%s'" %(worker_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row in result:
			dict={'worker_id':row[0],'image':row[1],'worker_name':row[2],'gender':row[3],'dob':row[4],'aadhar_number':row[5],'regis_date':row[6],'place':row[7],'address':row[8],'languages_known':row[9],'phone':row[10],'mobile':row[11],'email':row[12],'status':row[14]}
			list.append(dict)
		return render(request,'view_individual_worker.html',{'list':list})
def acceptworkerrequest(request):
		worker_id=request.GET['worker_id']
		cursor=connection.cursor()
		sql5="update tbl_login set status='true' where u_id='%s' and user_type='worker'" %(worker_id)
		
		cursor.execute(sql5)
		sql7="update tbl_worker set status='Active' where worker_id='%s'" %(worker_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Accepted! ');window.location='/homepolice/';</script>"
		return HttpResponse(html)
def rejectworkerrequest(request):
		worker_id=request.GET['worker_id']
		cursor=connection.cursor()
		sql5="update tbl_login set status='true' where u_id='%s' and user_type='worker'" %(worker_id)
		
		cursor.execute(sql5)
		sql7="update tbl_worker set status='Rejected' where worker_id='%s'" %(worker_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Rejected! ');window.location='/homepolice/';</script>"
		return HttpResponse(html)
def vieweditemp(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='employer' and u_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_emp where emp_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
					list.append(dict)
		return render(request,'edit_view_emp.html',{'list':list})
def edit_employer(request):
		cursor=connection.cursor()
		emp_id=request.GET['empid']
		sql1="select * from tbl_emp where emp_id='%s'" %(emp_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row in result:
			dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
			list.append(dict)
		return render(request,'edit_emp.html',{'list':list})
def update_employer(request):
		emp_id=request.GET['empid']
		Name=request.GET['name'] 
		Gender=request.GET['Gender']
		Office_name=request.GET['Firm_name']
		Aadhar_number=int(request.GET['Aadhar_number'])
		DOB=request.GET['DOB']
		Address=request.GET['Emp_address']
		Place=request.GET['Place']
		Phone=int(request.GET['Phone'])
		Mobile=int(request.GET['Mobile'])
		Email_id=request.GET['Email_id']
		
		cursor=connection.cursor()
	
		sql7="update tbl_emp set name='%s',gender='%s',firm_name='%s',aadhar_no='%s',dob='%s',emp_address='%s',place='%s',phone='%s',mobile='%s',email='%s' where emp_id='%s'" %(Name,Gender,Office_name,Aadhar_number,DOB,Address,Place,Phone,Mobile,Email_id,emp_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Editted! ');window.location='/homeemp/';</script>"
		
		return HttpResponse(html)
def viewworkerdetails(request):
		cursor=connection.cursor()
		list=[]
		
		sql1="select * from tbl_workerdetails"
		cursor.execute(sql1)
		result=cursor.fetchall()
		for row1 in result:
			dict={'worker_id':row1[0],'vacancy_id':row1[1],'qualification':row1[2],'experience':row1[3]}
			list.append(dict)
		return render(request,'view_shedduled_workerdetails.html',{'list':list})
def viewworker(request):
		cursor=connection.cursor()
		worker_id=request.GET['worker_id']
		list=[]
		sql1="select * from tbl_worker where worker_id='%s'"%(worker_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		for row1 in result:
			dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'regis_date':row[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
			list.append(dict)
		return render(request,'viewsheduledworker2.html',{'list':list})
def feedbackinsert(request):
		now=datetime.datetime.today()
		Emp_id=request.session['u_id']
		Worker_id=request.GET['worker_id']
		Feedback_title=request.GET['title'] 
		Feedback_description=request.GET['description']
		cursor=connection.cursor()
		
		sql4="insert into tbl_feedback(date,emp_id,worker_id,feedback_title,feedback_description)values('%s','%s','%s','%s','%s')"%(now,Emp_id,Worker_id,Feedback_title,Feedback_description) 
		cursor.execute(sql4)
		html="<script>alert('successfully inserted! ');window.location='/homeemp/';</script>"
		return HttpResponse(html)
def addfeedback(request):
		worker_id=request.GET['worker_id']
		return render(request,'feedback.html',{'worker_id':worker_id})
def viewemydetails(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='employer' and u_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_emp where emp_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
					list.append(dict)
		return render(request,'view_mydetails.html',{'list':list})
def viewempworker(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='worker' and status='true' "
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'worker_name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'regis_date':row[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
					list.append(dict)
		return render(request,'view_empworker.html',{'list':list})
def viewnoc1(request):
		cursor=connection.cursor()
		
		sql="select * from tbl_login where user_type='worker' and status='true' "
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				#sql1="select * from tbl_worker where worker_id='%s'"%(row1[3])
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'image':row[1],'worker_name':row[2],'gender':row[3],'dob':row[4],'aadhar_number':row[5],'regis_date':row[6],'place':row[7],'address':row[8],'languages_known':row[9],'phone':row[10],'mobile':row[11],'email':row[12],'status':row[14]}
					list.append(dict)
		return render(request,'view_noc1.html',{'list':list})
def viewnoc2(request):
		cursor=connection.cursor()
		list=[]
		worker_id=request.GET['worker_id']
		sql1="select * from tbl_noc where worker_id='%s' "%(worker_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		if 	(cursor.rowcount) > 0:
			for row in result:
				dict={'noc_id':row[0],'worker_id':row[1],'station_id':row[2],'date':row[3],'crime':row[4],'crime_details':row[5]}
				list.append(dict)
			return render(request,'view_noc2.html',{'list':list})
		else:
			html="<script>alert('no enoc ');window.location='/viewnoc1/';</script>"
			return HttpResponse(html)
def view_feedbackworker(request):
		cursor=connection.cursor()
		sql="select * from tbl_myworker where status='fixed' and emp_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[2])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'regis_date':row[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
					list.append(dict)
		return render(request,'view_feedbackworker.html',{'list':list})

def viewvacancy(request):
		cursor=connection.cursor()
		list=[]
		sql="select * from tbl_emp where emp_id='%s'"%(request.session['u_id'])
		
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row in result1:
			sql1="select * from tbl_vacancy where emp_id='%s'"%(row[0])
			cursor.execute(sql1)
			result=cursor.fetchall()
			for row1 in result:
				dict={'vacancy_id':row1[0],'date':row1[1],'emp_id':row1[2],'vacancy':row1[3],'vacancy_no':row1[4],'description':row1[5],'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
				list.append(dict)
		return render(request,'view_vacancy2.html',{'list':list})
def editvacancy1(request):
		cursor=connection.cursor()
		list=[]
		sql="select * from tbl_emp where emp_id='%s'"%(request.session['u_id'])
		
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row in result1:
			sql1="select * from tbl_vacancy where emp_id='%s'"%(row[0])
			cursor.execute(sql1)
			result=cursor.fetchall()
			for row1 in result:
				dict={'vacancy_id':row1[0],'date':row1[1],'emp_id':row1[2],'vacancy':row1[3],'vacancy_no':row1[4],'description':row1[5],'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
				list.append(dict)
		return render(request,'edit_vacancy1.html',{'list':list})
def editvacancy2(request):
		cursor=connection.cursor()
		vacancy_id=request.GET['vacancy_id']
		sql1="select * from tbl_vacancy where vacancy_id='%s'" %(vacancy_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row1 in result:
			dict={'vacancy_id':row1[0],'date':row1[1],'emp_id':row1[2],'vacancy':row1[3],'vacancy_no':row1[4],'description':row1[5]}
			list.append(dict)
		return render(request,'edit_vacancy2.html',{'list':list})
def editvacancy3(request):
		vacancy_id=request.GET['vacancyid']
		now=datetime.datetime.today()
		emp_id=request.session['u_id']
		Vacancy=request.GET['vacancy'] 
		Vacancy_num=request.GET['num']
		Description=request.GET['des']
		
		cursor=connection.cursor()
	
		sql7="update tbl_vacancy set date='%s',emp_id='%s',vacancy='%s',vacancy_no='%s',description='%s' where vacancy_id='%s' " %(now,emp_id,Vacancy,Vacancy_num,Description,vacancy_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Editted! ');window.location='/homeemp/';</script>"
		return HttpResponse(html)
def viewvacancyhome(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='employer'"
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_emp where emp_id='%s' and emp_id in(select emp_id from tbl_vacancy)"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'password':row[11],'status':row[12]}
					list.append(dict)
		return render(request,'view_vacancyhome.html',{'list':list})

def viewvacancyhome2(request):
		cursor=connection.cursor()
		Emp_id=request.GET['emp_id']
		sql1="select * from tbl_vacancy where emp_id='%s'" %(Emp_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row1 in result:
			dict={'vacancy_id':row1[0],'date':row1[1],'emp_id':row1[2],'vacancy':row1[3],'vacancy_no':row1[4],'description':row1[5]}
			list.append(dict)
		return render(request,'view_vacancyhome2.html',{'list':list})
def viewvacancyhome3(request):
		worker_id=request.session['u_id']
		vacancy_id=request.GET['vacancy_id']
		return render(request,'view_vacancyhome3.html',{'vacancy_id':vacancy_id})
def viewvacancyhome4(request):
		worker_id=request.session['u_id']
		vacancy_id=request.GET['v_id']
		Experience=request.GET['experience'] 
		Qualification=request.GET['qualification']
		cursor=connection.cursor()
		sql="select vacancy_id from tbl_workerdetails where worker_id='%s' and vacancy_id='%s'"%(worker_id,vacancy_id)
		cursor.execute(sql)
		if(cursor.rowcount>0): 
			html="<script>alert('Already applied! ');window.location='/homeadmin/';</script>"
		else:
			sql4="insert into tbl_workerdetails(worker_id,vacancy_id,experience,qualification)values('%s','%s','%s','%s')"%(worker_id,vacancy_id,Experience,Qualification) 
			cursor.execute(sql4)
			html="<script>alert('successfully inserted! ');window.location='/homeworker/';</script>"
		return HttpResponse(html)
def viewappliedvacancy(request):
		emp_id=request.session['u_id']
		cursor=connection.cursor()
		list=[]   
		sql="select * from tbl_vacancy where emp_id='%s'" %(request.session['u_id'])
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row in result1:
			sql1="select * from tbl_workerdetails INNER JOIN tbl_worker on tbl_workerdetails.worker_id=tbl_worker.worker_id where vacancy_id='%s' and status='Active'"%(row[0])
			cursor.execute(sql1)
			result=cursor.fetchall()
			for row1 in result:
				dict={'date':row[1],'emp_id':row[2],'vacancy':row[3],'vacancy_no':row[4],'description':row[5],'worker_id':row1[0],'vacancy_id':row1[1],'qualification':row1[2],'experience':row1[3]}
				list.append(dict)
		return render(request,'view_appliedvacancy.html',{'list':list})	
def viewappliedvacancy2(request):
		cursor=connection.cursor()
		v_id=request.GET['vacid']
		w_id=request.GET['worid']
		sql1="select * from tbl_worker where worker_id='%s'"%(w_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row in result:
				dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'regis_date':row[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11],'vaccancy_id':v_id}
				list.append(dict)
		return render(request,'view_appliedvacancy2.html',{'list':list})
def addmyworker(request):
		emp_id=request.session['u_id']
		worker_id=request.GET['worker_id']
		vacancy_id=request.GET['vacancy_id']
		Date=now 
		cursor=connection.cursor()
		sql1="select status from tbl_worker where worker_id='%s'"%(worker_id)
		cursor.execute(sql1)
		result2=cursor.fetchall()
		for r2 in result2:
			status1=r2[0]
		if(status1=='Active'):
			sql4="insert into tbl_myworker(emp_id,worker_id,vacancy_id,date,status)values('%s','%s','%s','%s','%s')"%(emp_id,worker_id,vacancy_id,Date,'fixed') 
			cursor.execute(sql4)
			sql5="update  tbl_worker set status='fixed' where worker_id='%s'"%(worker_id) 
			cursor.execute(sql5)
			html="<script>alert('successfully inserted! ');window.location='/homeemp/';</script>"
		else:
			html="<script>alert('Cannot add as myworker! ');window.location='/homeemp/';</script>"
		return HttpResponse(html)
def editfeedbackworker1(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='worker' and status='true' "
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'regis_date':row[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
					list.append(dict)
		return render(request,'editfeedbackworker1.html',{'list':list})
def editfeedbackworker2(request):
		cursor=connection.cursor()
		worker_id=request.GET['worker_id']
		sql1="select * from tbl_feedback where feedback_id=(select max(feedback_id) from tbl_feedback where worker_id='%s') " %(worker_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row1 in result:
			dict={'feedback_id':row1[0],'date':row1[1],'emp_id':row1[2],'worker_id':row1[3],'feedback_title':row1[4],'feedback_description':row1[5]}
			list.append(dict)
		return render(request,'edit_feedbackworker2.html',{'list':list})
def editfeedbackworker3(request):
		
		feedback_id=request.GET['feedbackid']
		now=datetime.datetime.today()
		
		Feedback_title=request.GET['feedback_title'] 
		Feedback_description=request.GET['des']
		
		cursor=connection.cursor()
	
		sql7="update tbl_feedback set date='%s',feedback_title='%s',feedback_description='%s' where feedback_id='%s'" %(now,Feedback_title,Feedback_description,feedback_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Editted!');window.location='/homeemp/';</script>"
		return HttpResponse(html)
def viewemydetailsworker(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='worker' and u_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'regis_date':row[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
					list.append(dict)
		return render(request,'view_mydetailsworker.html',{'list':list})
def viewmyworker(request):
		cursor=connection.cursor()
		list=[]
		sql="select * from tbl_myworker where status='fixed' and emp_id='%s'"%(request.session['u_id'])
		
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[2])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'date':row1[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
					list.append(dict)
		return render(request,'view_myworker.html',{'list':list})
def viewfeedback(request):
		cursor=connection.cursor()
		list=[]
		sql1="select * from tbl_feedback INNER JOIN tbl_worker on tbl_feedback.worker_id=tbl_worker.worker_id INNER JOIN tbl_emp on tbl_feedback.emp_id=tbl_emp.emp_id where tbl_feedback.emp_id='%s'"%(request.session['u_id'])
		cursor.execute(sql1)
		result=cursor.fetchall()
		#return HttpResponse(result)
		for row1 in result:
			dict={'feedback_id':row1[0],'date':row1[1],'emp_id':row1[2],'worker_id':row1[3],'feedback_title':row1[4],'feedback_description':row1[5],'worker_name':row1[8],'gender':row1[9],'address':row1[14],'mobile':row1[16],'email':row1[17]}
			list.append(dict)
			#return HttpResponse(row1)
		return render(request,'view_feedback.html',{'list':list})
def viewadmin(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='admin' and u_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_admin where admin_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row1 in result:
					dict={'admin_id':row1[0],'name':row1[1],'country':row1[2],'state':row1[3],'phone':row1[4],'mobile':row1[5],'email':row1[6]}
					list.append(dict)
		return render(request,'view_admin.html',{'list':list})
def editadmin1(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='admin' and u_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_admin where admin_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row1 in result:
					dict={'admin_id':row1[0],'name':row1[1],'country':row1[2],'state':row1[3],'phone':row1[4],'mobile':row1[5],'email':row1[6]}
					list.append(dict)
		return render(request,'edit_admin1.html',{'list':list})
def editadmin2(request):
		cursor=connection.cursor()
		admin_id=request.GET['admin_id']
		sql1="select * from tbl_admin where admin_id=(select max(admin_id) from tbl_admin where admin_id='%s') " %(admin_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row1 in result:
			dict={'admin_id':row1[0],'name':row1[1],'country':row1[2],'state':row1[3],'phone':row1[4],'mobile':row1[5],'email':row1[6]}
			list.append(dict)
		return render(request,'edit_admin2.html',{'list':list})
def editadmin3(request):
		
		admin_id=request.GET['admin_id']
		
		
		Name=request.GET['name'] 
		Country=request.GET['country']
		State=request.GET['state']
		Phone=request.GET['phone']
		Mobile=request.GET['mobile']
		Email=request.GET['email']
		
		cursor=connection.cursor()
	
		sql7="update tbl_admin set name='%s',country='%s',state='%s',phone='%s',mobile='%s',email='%s' where admin_id='%s'" %(Name,Country,State,Phone,Mobile,Email)
		cursor.execute(sql7)
		html="<script>alert('successfully Editted!');window.location='/homeadmin/';</script>"
def viewadminworker(request):
		cursor=connection.cursor()
		list=[]
		sql1="select * from tbl_worker "
		cursor.execute(sql1)
		result=cursor.fetchall()
		for row in result:
			dict={'worker_id':row[0],'image':row[1],'worker_name':row[2],'gender':row[3],'dob':row[4],'aadhar_number':row[5],'regis_date':row[6],'place':row[7],'address':row[8],'languages_known':row[9],'phone':row[10],'mobile':row[11],'email':row[12],'status':row[14]}
			list.append(dict)
		return render(request,'view_adminworker.html',{'list':list})
def editadminworker(request):
		cursor=connection.cursor()
		list=[]
		sql1="select * from tbl_worker "
		cursor.execute(sql1)
		result=cursor.fetchall()
		for row in result:
					dict={'worker_id':row[0],'image':row[1],'worker_name':row[2],'gender':row[3],'dob':row[4],'aadhar_number':row[5],'regis_date':row[6],'place':row[7],'address':row[8],'languages_known':row[9],'phone':row[10],'mobile':row[11],'email':row[12],'status':row[14]}
					list.append(dict)
		return render(request,'edit_adminworker.html',{'list':list})
def editadminworker2(request):
		cursor=connection.cursor()
		worker_id=request.GET['worker_id']
		sql1="select * from tbl_worker where worker_id='%s'" %(worker_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row in result:
			dict={'worker_id':row[0],'image':row[1],'worker_name':row[2],'gender':row[3],'dob':row[4],'aadhar_number':row[5],'regis_date':row[6],'place':row[7],'address':row[8],'languages_known':row[9],'phone':row[10],'mobile':row[11],'email':row[12],'status':row[14]}
			list.append(dict)
		return render(request,'edit_adminworker2.html',{'list':list})
def editadminworker3(request):
		worker_id=request.GET['worker_id']
		Name=request.GET['name']
		Gender=request.GET['gender']
		DOB=request.GET['dob']
		Aadhar_number=request.GET['aadhar_number']
		now=datetime.datetime.today()
		place=request.GET['place']
		address=request.GET['address']
		languages_known=request.GET['languages_known']
		phone=request.GET['phone']
		mobile=request.GET['mobile']
		email=request.GET['email']
		
		
		cursor=connection.cursor()
	
		sql7="update tbl_worker set worker_name='%s',gender='%s',dob='%s',aadhar_number='%s',regis_date='%s',place='%s',address='%s',languages_known='%s',phone='%s',mobile='%s',email='%s' where worker_id='%s' " %(Name,Gender,DOB,Aadhar_number,now,place,address,languages_known,phone,mobile,email,worker_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Editted! ');window.location='/homeadmin/';</script>"
		return HttpResponse(html)
def viewempadmin(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='employer' "
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_emp where emp_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'emp_id':row[0],'name':row[1],'gender':row[2],'firm_name':row[3],'aadhar_no':row[4],'dob':row[5],'emp_address':row[6],'place':row[7],'phone':row[8],'mobile':row[9],'email':row[10],'status':row[12]}
					list.append(dict)
		return render(request,'viewempadmin.html',{'list':list})
	

def viewfeedbackworkerhome(request):
		cursor=connection.cursor()
		list=[]
		sql1="select * from tbl_feedback where worker_id='%s'"%(request.session['u_id'])
		cursor.execute(sql1)
		result1=cursor.fetchall()
		for row1 in result1:
			
			dict={'feedback_id':row1[0],'date':row1[1],'emp_id':row1[2],'worker_id':row1[3],'feedback_title':row1[4],'feedback_description':row1[5]}
			list.append(dict)
		return render(request,'view_feedbackworkerhome.html',{'list':list})
def viewmyworker_jobsheddule(request):
		cursor=connection.cursor()
		list=[]
		sql="select * from tbl_myworker where status='fixed' and emp_id='%s'"%(request.session['u_id'])
		
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[2])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'date':row1[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
					list.append(dict)
		return render(request,'viewmyworker_jobsheddule.html',{'list':list})
def jobsheddule1(request):
		worker_id=request.GET['worker_id']
		return render(request,'jobsheddule.html',{'worker_id':worker_id})
def jobsheddule2(request):
		Emp_id=request.session['u_id']
		Worker_id=request.GET['worker_id']
		Job_details=request.GET['work'] 
		Salary=request.GET['salary']
		now=datetime.datetime.today()
		Working_houres=request.GET['working_houres']
		
		cursor=connection.cursor()
		
		sql4="insert into tbl_workershedule(emp_id,worker_id,job_details,salary,time_from,working_houres)values('%s','%s','%s','%s','%s','%s')"%(Emp_id,Worker_id,Job_details,Salary,now,Working_houres) 
		cursor.execute(sql4)
		html="<script>alert('successfully inserted! ');window.location='/homeemp/';</script>"
		return HttpResponse(html)
"""def viewjobshedule(request):
		cursor=connection.cursor()
		list=[]
		sql="select * from tbl_myworker where status='fixed' and emp_id='%s'"%(request.session['u_id'])
		
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[2])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'name':row[1],'gender':row[2],'dob':row[3],'aadhar_number':row[4],'date':row1[5],'place':row[6],'address':row[7],'languages_known':row[8],'phone':row[9],'mobile':row[10],'email':row[11]}
					list.append(dict)
		return render(request,'viewjobshedule.html',{'list':list})"""
def changepaswd (request):
	cursor=connection.cursor()
	username=request.GET['user']
	old=request.GET['opass']
	new=request.GET['npass']
	re=request.GET['rpass']
	sql="select * from tbl_login where u_id='%s'"%(request.session['u_id'])
	cursor.execute(sql)
	result=cursor.fetchall()
	for row in result:
		p1=row[1]
	if((p1 == old) & ( new== re)):
		sql1="update tbl_login set password='%s' where u_id='%s' and user_type='%s'"%(re,request.session['u_id'],request.session['user_type'])
		cursor.execute(sql1)
		html="<script>alert('successfully changed password! ');window.location='/l/';</script>"
	else:
		html="<script>alert('Cannot be changed! ');window.location='/l/';</script>"
	return HttpResponse(html)
def viewadminpolice(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='police'"
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_policestation where station_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'station_id':row[0],'branch':row[1],'address':row[2],'phone':row[3],'mobile':row[4],'email':row[5],'district':row[6],'city':row[7],'state':row[8],'password':row[9]}
					list.append(dict)
		return render(request,'viewadminpolice.html',{'list':list})
def viewpolice(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='police' and u_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_policestation where station_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'station_id':row[0],'branch':row[1],'address':row[2],'phone':row[3],'mobile':row[4],'email':row[5],'district':row[6],'city':row[7],'state':row[8],'password':row[9]}
					list.append(dict)
		return render(request,'viewpolice.html',{'list':list})
def editpolice1(request):
		cursor=connection.cursor()
		sql="select * from tbl_login where user_type='police' and u_id='%s'"%(request.session['u_id'])
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				sql1="select * from tbl_policestation where station_id='%s'"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'station_id':row[0],'branch':row[1],'address':row[2],'phone':row[3],'mobile':row[4],'email':row[5],'district':row[6],'city':row[7],'state':row[8],'password':row[9]}
					list.append(dict)
		return render(request,'editpolice1.html',{'list':list})
def editpolice2(request):
		cursor=connection.cursor()
		station_id=request.GET['stationid']
		sql1="select * from tbl_policestation where station_id=(viewvacancy max(station_id) from tbl_policestation where station_id='%s') " %(station_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		list=[]
		for row in result:
			dict={'station_id':row[0],'branch':row[1],'address':row[2],'phone':row[3],'mobile':row[4],'email':row[5],'district':row[6],'city':row[7],'state':row[8],'password':row[9]}
			list.append(dict)
		return render(request,'editpolice2.html',{'list':list})
def editpolice3(request):
		
		station_id=request.GET['stationid']
		
		
		Branch=request.GET['branch'] 
		Address=request.GET['address']
		
		Phone=request.GET['phone']
		Mobile=request.GET['mobile']
		Email=request.GET['email']
		District=request.GET['district']
		City=request.GET['city']
		State=request.GET['state']
		cursor=connection.cursor()
	
		sql7="update tbl_policestation set branch='%s',address='%s',phone='%s',mobile='%s',email='%s',district='%s',city='%s',state='%s' where station_id='%s'" %(Branch,Address,Phone,Mobile,Email,District,City,State,station_id)
		cursor.execute(sql7)
		html="<script>alert('successfully Editted!');window.location='/homepolice/';</script>"
		return HttpResponse(html)
def deletenoc1(request):
		cursor=connection.cursor()
		
		sql="select * from tbl_login where user_type='worker' and status='true' "
		list=[]
		cursor.execute(sql)
		result1=cursor.fetchall()
		for row1 in result1:
				#sql1="select * from tbl_worker where worker_id='%s'"%(row1[3])
				sql1="select * from tbl_worker where worker_id='%s'"%(row1[3])
				sql1="select * from tbl_worker where worker_id='%s' and worker_id in(select worker_id from tbl_noc)"%(row1[3])
				cursor.execute(sql1)
				result=cursor.fetchall()
				for row in result:
					dict={'worker_id':row[0],'image':row[1],'worker_name':row[2],'gender':row[3],'dob':row[4],'aadhar_number':row[5],'regis_date':row[6],'place':row[7],'address':row[8],'languages_known':row[9],'phone':row[10],'mobile':row[11],'email':row[12],'status':row[14]}
					list.append(dict)
		return render(request,'deletenoc1.html',{'list':list})
def deletenoc2(request):
		cursor=connection.cursor()
		list=[]
		worker_id=request.GET['worker_id']
		sql1="select * from tbl_noc where worker_id='%s' "%(worker_id)
		cursor.execute(sql1)
		result=cursor.fetchall()
		for row in result:
			dict={'noc_id':row[0],'worker_id':row[1],'station_id':row[2],'date':row[3],'crime':row[4],'crime_details':row[5]}
			list.append(dict)
		return render(request,'deletenoc2.html',{'list':list})
def deletenoc3(request):
		
		cursor=connection.cursor()
		noc_id=request.GET['noc_id']
		sql4="delete from tbl_noc where noc_id='%s'"%(noc_id)
		cursor.execute(sql4)
		html="<script>alert('successfully deleted! ');window.location='/homepolice/';</script>"
		return HttpResponse(html)

		
	
	
		
	

		
		
	








