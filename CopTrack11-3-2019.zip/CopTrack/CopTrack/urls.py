"""CopTrack URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import  include, url,patterns
from Track.views import *
from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static
admin.autodiscover()

urlpatterns = [
	url(r'^l/',TemplateView.as_view(template_name = 'login.html')),
	url(r'^home/',TemplateView.as_view(template_name = 'index.html')),
	url(r'^regadmin/',TemplateView.as_view(template_name = 'reg_admin.html')),
	url(r'^reginsert/',reginsert, name = 'reginsert'),
	url(r'^emp/',TemplateView.as_view(template_name = 'reg_emp.html')),
	url(r'^regempinsert/',regempinsert, name = 'regempinsert'),
	url(r'^police/',TemplateView.as_view(template_name = 'reg_policestation.html')),
	url(r'^regpoliceinsert/',regpoliceinsert, name = 'regpoliceinsert'),
	url(r'^registration/',TemplateView.as_view(template_name = 'reg_worker.html')),
	url(r'^regworkerinsert/',regworkerinsert, name = 'regworkerinsert'),
	#url(r'^registration/',TemplateView.as_view(template_name = 'vacancy.html')),
	#url(r'^vacancyinsert/',vacancyinsert, name = 'vacancyinsert'),

	url(r'^searchlogin/',searchlogin, name = 'searchlogin'),
	url(r'^$',TemplateView.as_view(template_name = 'index.html')),
	url(r'^viewacceptemprequest/',viewacceptemprequest, name = 'viewacceptemprequest'),
	url(r'^viewemprequest/',viewemprequest, name = 'viewemprequest'),
	url(r'^acceptemprequest$',acceptemprequest, name = 'acceptemprequest'),
	url(r'^rejectemprequest$',rejectemprequest, name = 'rejectemprequest'),
	url(r'^viewworkeraccept/',viewworkeraccept, name = 'viewworkeraccept'),
	url(r'^acceptworkerrequest$',acceptworkerrequest, name = 'acceptworkerrequest'),
	url(r'^vieweditemp/$',vieweditemp, name = 'vieweditemp'),
	url(r'^edit_employer/$',edit_employer, name = 'edit_employer'),
	url(r'^update_employer/$',update_employer, name = 'update_employer'),
	url(r'^addvacancy/',TemplateView.as_view(template_name = 'vacancy.html')),
	url(r'^vacancyinsert/',vacancyinsert, name = 'vacancyinsert'),
	url(r'^addnoc/',TemplateView.as_view(template_name = 'noc.html')),
	url(r'^noc_insert/',noc_insert, name = 'noc_insert'),
	url(r'^viewvacancydetails/',viewvacancydetails, name = 'viewvacancydetails'),
	url(r'^insertworkerdetails/',insertworkerdetails, name = 'insertworkerdetails'),
	url(r'^insertworkerdetails/',insertworkerdetails, name = 'insertworkerdetails'),
	url(r'^viewworkerdetails/',viewworkerdetails, name = 'viewworkerdetails'),
	url(r'^viewworker/',viewworker, name = 'viewworker'),
	url(r'^viewworkerdetails1/',TemplateView.as_view(template_name = 'view_shedduled_workerdetails.html')),
	url(r'^addfeedback/',TemplateView.as_view(template_name = 'feedback.html')),
	url(r'^feedbackinsert/',feedbackinsert, name = 'feedbackinsert'),
	url(r'^homeworker/',TemplateView.as_view(template_name = 'home_worker.html')),
	url(r'^homeamin/',TemplateView.as_view(template_name = 'home_admin.html')),
	url(r'^homeemp/',TemplateView.as_view(template_name = 'home_emp.html')),
	url(r'^homepolice/',TemplateView.as_view(template_name = 'home_police.html')),
	url(r'^viewemydetails/',viewemydetails, name = 'viewemydetails'),
	url(r'^viewempworker/',viewempworker, name = 'viewempworker'),
	url(r'^viewnoc1/',viewnoc1, name = 'viewnoc1'),
	url(r'^viewnoc2/',viewnoc2, name = 'viewnoc2'),
	url(r'^view_feedbackworker/',view_feedbackworker, name = 'view_feedbackworker'),
	url(r'^addvacancy/',TemplateView.as_view(template_name = 'vacancy.html')),
	url(r'^vacancyinsert/',vacancyinsert, name = 'vacancyinsert'),
	url(r'^viewvacancy/',viewvacancy, name = 'viewvacancy'),
	
	url(r'^editvacancy1/',editvacancy1, name = 'editvacancy1'),
	url(r'^editvacancy2/',editvacancy2, name = 'editvacancy2'),
	url(r'^editvacancy3/',editvacancy3, name = 'editvacancy3'),
	url(r'^viewvacancyhome/',viewvacancyhome, name = 'viewvacancyhome'),
	url(r'^viewvacancyhome2/',viewvacancyhome2, name = 'viewvacancyhome2'),
	url(r'^viewvacancyhome3/',viewvacancyhome3, name = 'viewvacancyhome3'),
	
	url(r'^viewvacancyhome4/',viewvacancyhome4, name = 'viewvacancyhome4'),
	url(r'^viewappliedvacancy/',viewappliedvacancy, name = 'viewappliedvacancy'),
	url(r'^viewappliedvacancy2/',viewappliedvacancy2, name = 'viewappliedvacancy2'),
	
]
